<footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2022 <a href="">Narendra | Kost</a>.</strong> All rights reserved | Repost by <a href='' title='' target='_blank'></a>

</footer>