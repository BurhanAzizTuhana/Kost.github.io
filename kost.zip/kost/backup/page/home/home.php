<div class="products-catagories-area clearfix">
            <div class="amado-pro-catagory clearfix">

                <!-- Single Catagory -->
                <div class="single-products-catagory clearfix">
                    <a href="index.php?page=MenuKosan">
                        <img src="css/img/kota/plg.jpg" alt="">
                        <!-- Hover Content -->
                        <div class="hover-content">
                            <div class="line"></div>
                            <p style="color:white">Kota</p>
                            <h4 style="color:white">Palembang</h4>
                        </div>
                    </a>
                </div>

                <!-- Single Catagory -->
                <div class="single-products-catagory clearfix">
                    <a href="index.php?page=MenuKosan">
                        <img src="css/img/kota/jkt.jpg" alt="">
                        <!-- Hover Content -->
                        <div class="hover-content">
                            <div class="line"></div>
                            <p style="color:white">Kota</p>
                            <h4 style="color:white">Jakarta</h4>
                        </div>
                    </a>
                </div>

                <!-- Single Catagory -->
                <div class="single-products-catagory clearfix">
                    <a href="index.php?page=MenuKosan">
                        <img src="css/img/kota/sby.jpg" alt="">
                        <!-- Hover Content -->
                        <div class="hover-content">
                            <div class="line"></div>
                            <p style="color:white">Kota</p>
                            <h4 style="color:white">Surabaya</h4>
                        </div>
                    </a>
                </div>

                <!-- Single Catagory -->
                <div class="single-products-catagory clearfix">
                    <a href="index.php?page=MenuKosan">
                        <img src="css/img/kota/yogya.jpg" alt="" style="height:300px;">
                        <!-- Hover Content -->
                        <div class="hover-content">
                            <div class="line"></div>
                            <p style="color:white">Kota</p>
                            <h4 style="color:white">Yogyakarta</h4>
                        </div>
                    </a>
                </div>

                <!-- Single Catagory -->
                <div class="single-products-catagory clearfix">
                    <a href="index.php?page=MenuKosan">
                        <img src="css/img/kota/makassar.jpg" alt="">
                        <!-- Hover Content -->
                        <div class="hover-content">
                            <div class="line"></div>
                            <p style="color:white">Kota</p>
                            <h4 style="color:white">Makassar</h4>
                        </div>
                    </a>
                </div>

                <!-- Single Catagory -->
                <div class="single-products-catagory clearfix">
                    <a href="index.php?page=MenuKosan">
                        <img src="css/img/kota/bali.jpg" alt="">
                        <!-- Hover Content -->
                        <div class="hover-content">
                            <div class="line"></div>
                            <p style="color:white">Kota</p>
                            <h4 style="color:white">Bali</h4>
                        </div>
                    </a>
                </div>

                <!-- Single Catagory -->
                <div class="single-products-catagory clearfix">
                    <a href="index.php?page=MenuKosan">
                        <img src="css/img/kota/pdg.jpg" style="height:333px;" alt="">
                        <!-- Hover Content -->
                        <div class="hover-content">
                            <div class="line"></div>
                            <p style="color:white">Kota</p>
                            <h4 style="color:white">Padang</h4>
                        </div>
                    </a>
                </div>

                <!-- Single Catagory -->
                <div class="single-products-catagory clearfix">
                    <a href="index.php?page=MenuKosan">
                        <img src="css/img/kota/mlg.jpg" style="height:290px;" alt="">
                        <!-- Hover Content -->
                        <div class="hover-content">
                            <div class="line"></div>
                            <p style="color:white">Kota</p>
                            <h4 style="color:white">Malang</h4>
                        </div>
                    </a>
                </div>

                <!-- Single Catagory -->
                <div class="single-products-catagory clearfix">
                    <a href="index.php?page=MenuKosan">
                        <img src="css/img/kota/bdg.jpg" style="height:233px;" alt="">
                        <!-- Hover Content -->
                        <div class="hover-content">
                            <div class="line"></div>
                            <p style="color:white">Kota</p>
                            <h4 style="color:white">Bandung</h4>
                        </div>
                    </a>
                </div>
            </div>
        </div>